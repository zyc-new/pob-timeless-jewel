# 永恒珠宝精准规划：独立补丁包

适用版本：

```text
Path of Building Community 2.67.2
PoE1 天赋树 3.29
```

## 内容

```text
patches/
  TreeTab.patch      # 天赋树入口按钮和布局
  Build.patch        # <TimelessPlanner> 配置保存/加载
  Launch.patch       # 可选：启动时加载 AgentBridge
  AgentBridge.patch  # 可选：AI 自然语言查询命令（已有基础版时用）

new-files/
  Classes/TimelessJewelPlanner.lua
  Modules/TimelessPlannerSearch.lua
  Modules/TimelessJewelTrade.lua

full-files/
  Launch.lua
  Modules/AgentBridge.lua
```

## 安装

先备份：

```text
Classes/TreeTab.lua
Modules/Build.lua
Modules/AgentBridge.lua
Launch.lua
```

在 PoB 根目录执行：

```powershell
git apply --check patches/TreeTab.patch
git apply --check patches/Build.patch
```

确认后：

```powershell
git apply patches/TreeTab.patch
git apply patches/Build.patch
```

如果只需要面板插件，不要应用 `AgentBridge.patch`。

需要 AI 自然语言查询时：

- **已有基础版 AgentBridge 和 Launch 启动钩子**：应用 `AgentBridge.patch`；
- **没有 AgentBridge 的新用户**：不要再 apply AgentBridge.patch，直接复制完整文件：
  ```text
  full-files/Modules/AgentBridge.lua -> Modules/
  full-files/Launch.lua              -> Launch.lua
  ```
  这会把 AgentBridge 及启动加载钩子一起装上；
- **Launch 有自定义改动**：不要覆盖 `Launch.lua`，改应用：
  ```powershell
  git apply patches/Launch.patch
  ```

然后复制 `new-files` 下对应文件到 PoB：

```text
new-files/Classes/TimelessJewelPlanner.lua  -> Classes/
new-files/Modules/TimelessPlannerSearch.lua -> Modules/
new-files/Modules/TimelessJewelTrade.lua    -> Modules/
```

重启中文 PoB，天赋树底部会出现“精准规划”。

## 注意

- `AgentBridge.patch` 基于基础版 AgentBridge；
  如果对方 AgentBridge 已有其他修改，先手动合并，不要强行 apply。
- `full-files/Modules/AgentBridge.lua` 是完整版本，只用于没有基础版的新用户；
  已经应用过 `AgentBridge.patch` 的用户不要再用完整文件覆盖。
- `AgentBridge` 只监听 `127.0.0.1:49090`，但目前没有 token 鉴权；
  只监听本机，不要暴露到公网。
- 补丁只适用于 2.67.2；其他版本请只复制新增文件并手动合入改动。
- 需要中文 PoeCharm3 环境。
